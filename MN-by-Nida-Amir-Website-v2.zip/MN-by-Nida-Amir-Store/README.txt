# MN by Nida Amir — Official Luxury Clothing Store Website

## What's Inside This ZIP Package
1. `index.html` — Complete, standalone luxury e-commerce store with vibrant 2026 festive colors, Admin Panel, editable Brand/Lawn names, 10 languages, 6-currency converter, Size Chart, Order Tracking, Customer Reviews, and Custom Wallpaper Studio.

## How to Publish Online for Free (2 Minutes)
1. Unzip this folder on your phone or computer.
2. Go to https://app.netlify.com/drop (or Vercel / GitHub Pages).
3. Drag and drop the unzipped folder (containing `index.html`).
4. Your live store URL will be ready immediately!

## Default Admin Login
- Click **Admin** in the top navigation bar.
- Default PIN: `1234` (You can change this anytime inside **Admin -> Store & Security**).
- Use **Admin -> Brand / Lawn Names** to add, rename, or remove any Lawn or Designer brand names anytime!
